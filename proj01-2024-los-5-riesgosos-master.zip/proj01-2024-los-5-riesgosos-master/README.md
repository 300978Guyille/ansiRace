<img src="https://raw.githubusercontent.com/cc3-ug/logo/master/cc3.jpg" width="145px" align="right" />

# Project 1 - C & RISC-V

[![License](https://img.shields.io/github/license/cc3-ug/proj01-c-riscv)](https://github.com/cc3-ug/proj01-c-riscv/blob/master/LICENSE)
